﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("Ultimate Mobile - InAppPurchases")]
	[Tooltip("Restore purchases, restored event will be fired for ectach restored purchase")]
	public class UM_RestorePurchases : FsmStateAction {
		
		[Tooltip("Event fired when Product restored")]
		public FsmEvent ProductRestored;
		
		[Tooltip("Restored ProductId")]
		public FsmString RestoredProductId;
		
		[Tooltip("Event fired when Purchase restored")]
		public FsmEvent RestoreActionFinished;	
		
		public override void Reset() {

		}
		
		
		public override void OnEnter() {

			if (!UM_InAppPurchaseManager.instance.IsConnected) {
				UM_InAppPurchaseManager.Client.OnServiceConnected += OnStoreInitComplete;
				UM_InAppPurchaseManager.instance.Connect();
			} else {
				OnBillingInited();
			}
			
		}

		private void OnStoreInitComplete (UM_BillingConnectionResult res) {
			UM_InAppPurchaseManager.Client.OnServiceConnected -= OnStoreInitComplete;
			if(res.isSuccess) {
				OnBillingInited();
			} else {
				OnPurchasesRestoreFinishedAction(null);
			}
		}
		
		private void OnBillingInited() {
			UM_InAppPurchaseManager.Client.OnPurchaseFinished += OnPurchaseFlowFinishedAction;
			UM_InAppPurchaseManager.Client.OnRestoreFinished += OnPurchasesRestoreFinishedAction;
			UM_InAppPurchaseManager.instance.RestorePurchases ();
		}	


		void OnPurchasesRestoreFinishedAction (UM_BaseResult res) {
			Fsm.Event(RestoreActionFinished);
			Unsubuscibe();
			Finish();
		}

		void OnPurchaseFlowFinishedAction (UM_PurchaseResult res) {
			if(res.isSuccess) {
				RestoredProductId.Value = res.product.id;
				Fsm.Event(ProductRestored);
			}
		}

		void Unsubuscibe() {
			UM_InAppPurchaseManager.Client.OnServiceConnected -= OnStoreInitComplete;
			UM_InAppPurchaseManager.Client.OnPurchaseFinished -= OnPurchaseFlowFinishedAction;
			UM_InAppPurchaseManager.Client.OnRestoreFinished -= OnPurchasesRestoreFinishedAction;
		}


		void OnDestroy() {
			Unsubuscibe();
		}
	}
}
